require './GameScreen'

class Player
  def initialize(board)
    @board=board
  end

  def play(column)
    raise "Not implemented in this class"
  end
end
