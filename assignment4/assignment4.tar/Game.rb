require 'gtk2'

class Game

def menu_screen 
    
end

end


