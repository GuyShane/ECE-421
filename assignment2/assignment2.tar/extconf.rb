require 'mkmf'
create_makefile('delay')
